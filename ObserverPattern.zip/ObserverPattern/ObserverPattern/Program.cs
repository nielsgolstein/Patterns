﻿using ObserverPattern.src;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ObserverPattern
{
    /// <summary>
    /// Ignored this class because it is static.
    /// </summary>
    public class Program
    {
        static void Main(string[] args)
        {
            App app = new App();
        }
    }
}
