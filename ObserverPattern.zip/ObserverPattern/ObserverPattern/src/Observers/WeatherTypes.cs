﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ObserverPattern.src.Observers
{
    /// <summary>
    /// Just diffirent types of weater
    /// </summary>
    public enum WeatherTypes
    {
        RAIN, SUNNY, CLOUDLY
    }
}
